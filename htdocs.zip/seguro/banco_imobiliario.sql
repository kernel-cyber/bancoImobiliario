-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27/05/2024 às 22:53
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco_imobiliario`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `game_status`
--

CREATE TABLE `game_status` (
  `id` int(11) NOT NULL,
  `reset_status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `game_status`
--

INSERT INTO `game_status` (`id`, `reset_status`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `game_timer`
--

CREATE TABLE `game_timer` (
  `id` int(11) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `remaining_time` int(11) DEFAULT 7200
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `game_timer`
--

INSERT INTO `game_timer` (`id`, `start_time`, `remaining_time`) VALUES
(1, '2024-05-26 04:35:48', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogando`
--

CREATE TABLE `jogando` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `objetivoId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `jogando`
--

INSERT INTO `jogando` (`id`, `userId`, `nickname`, `objetivoId`) VALUES
(604, 9, 'Carol', 2),
(605, 13, 'Windsor', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `read` tinyint(1) DEFAULT 0,
  `type` varchar(50) NOT NULL DEFAULT 'notification'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `created_at`, `read`, `type`) VALUES
(18406, 17, 'Carol entrou na partida.', '2024-05-27 20:22:31', 0, 'join'),
(18407, 11, 'Carol entrou na partida.', '2024-05-27 20:22:31', 0, 'join'),
(18408, 10, 'Carol entrou na partida.', '2024-05-27 20:22:31', 0, 'join'),
(18409, 12, 'Carol entrou na partida.', '2024-05-27 20:22:31', 0, 'join'),
(18411, 17, 'Windsor entrou na partida.', '2024-05-27 20:22:35', 0, 'join'),
(18413, 11, 'Windsor entrou na partida.', '2024-05-27 20:22:35', 0, 'join'),
(18414, 10, 'Windsor entrou na partida.', '2024-05-27 20:22:35', 0, 'join'),
(18415, 12, 'Windsor entrou na partida.', '2024-05-27 20:22:35', 0, 'join'),
(18417, 17, 'Carol recebeu R$ 89.000 do banco.', '2024-05-27 20:23:12', 0, 'success'),
(18418, 11, 'Carol recebeu R$ 89.000 do banco.', '2024-05-27 20:23:12', 0, 'success'),
(18419, 10, 'Carol recebeu R$ 89.000 do banco.', '2024-05-27 20:23:12', 0, 'success'),
(18420, 12, 'Carol recebeu R$ 89.000 do banco.', '2024-05-27 20:23:12', 0, 'success'),
(18423, 17, 'Windsor recebeu R$ 89.000 do banco.', '2024-05-27 20:23:15', 0, 'success'),
(18425, 11, 'Windsor recebeu R$ 89.000 do banco.', '2024-05-27 20:23:15', 0, 'success'),
(18426, 10, 'Windsor recebeu R$ 89.000 do banco.', '2024-05-27 20:23:15', 0, 'success'),
(18427, 12, 'Windsor recebeu R$ 89.000 do banco.', '2024-05-27 20:23:15', 0, 'success'),
(18429, 17, 'Windsor recebeu R$ 8.000.000 do banco.', '2024-05-27 20:23:19', 0, 'success'),
(18431, 11, 'Windsor recebeu R$ 8.000.000 do banco.', '2024-05-27 20:23:19', 0, 'success'),
(18432, 10, 'Windsor recebeu R$ 8.000.000 do banco.', '2024-05-27 20:23:19', 0, 'success'),
(18433, 12, 'Windsor recebeu R$ 8.000.000 do banco.', '2024-05-27 20:23:19', 0, 'success'),
(18435, 17, 'Windsor recebeu R$ 78.000.000 do banco.', '2024-05-27 20:24:25', 0, 'success'),
(18437, 11, 'Windsor recebeu R$ 78.000.000 do banco.', '2024-05-27 20:24:25', 0, 'success'),
(18438, 10, 'Windsor recebeu R$ 78.000.000 do banco.', '2024-05-27 20:24:25', 0, 'success'),
(18439, 12, 'Windsor recebeu R$ 78.000.000 do banco.', '2024-05-27 20:24:25', 0, 'success'),
(18440, 17, 'Um jogador atingiu R$ 30.000.000.', '2024-05-27 20:24:25', 0, 'rico'),
(18442, 11, 'Um jogador atingiu R$ 30.000.000.', '2024-05-27 20:24:25', 0, 'rico'),
(18443, 10, 'Um jogador atingiu R$ 30.000.000.', '2024-05-27 20:24:25', 0, 'rico'),
(18444, 12, 'Um jogador atingiu R$ 30.000.000.', '2024-05-27 20:24:25', 0, 'rico'),
(18447, 17, 'Windsor recebeu R$ 78.000 do banco.', '2024-05-27 20:24:53', 0, 'success'),
(18449, 11, 'Windsor recebeu R$ 78.000 do banco.', '2024-05-27 20:24:53', 0, 'success'),
(18450, 10, 'Windsor recebeu R$ 78.000 do banco.', '2024-05-27 20:24:53', 0, 'success'),
(18451, 12, 'Windsor recebeu R$ 78.000 do banco.', '2024-05-27 20:24:53', 0, 'success'),
(18453, 17, 'Windsor pagou R$ 78.000.000 ao banco.', '2024-05-27 20:34:41', 0, 'success'),
(18454, 9, 'Windsor pagou R$ 78.000.000 ao banco.', '2024-05-27 20:34:41', 0, 'success'),
(18455, 11, 'Windsor pagou R$ 78.000.000 ao banco.', '2024-05-27 20:34:41', 0, 'success'),
(18456, 10, 'Windsor pagou R$ 78.000.000 ao banco.', '2024-05-27 20:34:41', 0, 'success'),
(18457, 12, 'Windsor pagou R$ 78.000.000 ao banco.', '2024-05-27 20:34:41', 0, 'success');

-- --------------------------------------------------------

--
-- Estrutura para tabela `objetivos`
--

CREATE TABLE `objetivos` (
  `id` int(11) NOT NULL,
  `nome_objetivo` varchar(255) DEFAULT NULL,
  `descricao_objetivo` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `objetivo1` varchar(255) DEFAULT NULL,
  `objetivo2` varchar(255) DEFAULT NULL,
  `objetivo3` varchar(255) DEFAULT NULL,
  `objetivo4` varchar(255) DEFAULT NULL,
  `assigned` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `objetivos`
--

INSERT INTO `objetivos` (`id`, `nome_objetivo`, `descricao_objetivo`, `status`, `objetivo1`, `objetivo2`, `objetivo3`, `objetivo4`, `assigned`) VALUES
(1, 'Magnata das Conexões', 'Adquirir ação de transporte e construir pelo menos 8 casas em propriedades próximas a ação.', 0, 'Ação de Transporte', '8 Casas', '', '', 1),
(2, 'Mestre da Comunicação', 'Controlar as ações da Emissora de TV e da Estrela Card e construir pelo menos 6 casas em propriedades no conjunto roxo.', 0, 'Ações Card & TV', '6 <font color=\"purple\"><b>Casas</b></font>', '', '', 1),
(3, 'Urbanista', 'Adquirir um conjunto completo de propriedades de qualquer cor e construir 4 hotéis nesse conjunto.', 0, '1 Conj.', '2 Hotéis', '', '', 0),
(4, 'Comerciante Estratégico', 'Adquirir todos os conjuntos de propriedades de cores laranja e amarelo, e investir em pelo menos duas diferentes ações.', 0, 'Conj. <font color=\"orange\"><b>Laranja</b></font> e <font color=\"gold\"><b>Amarelo</b></font>', '2 Ações', '', '', 0),
(5, 'Colecionador Versátil', 'Possuir um conjunto completo de propriedades de qualquer cor e construir 5 casas nessas propriedades. Adquirir ações de pelo menos três tipos diferentes.', 0, '1 Conj.', '5 Casas', '3 Ações', '', 0),
(6, 'Estrategista de Elite', 'Adquirir todas as propriedades do conjunto verde escuro, construir 2 hotéis nessas propriedades e adquirir uma ação de dois tipos diferentes de empresas.', 0, '1 <font color=\"#006400\"><b>Conj.</b></font>', '2 Hotéis', '2 Ações', '', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `message`, `created_at`) VALUES
(2810, 9, 'Carol recebeu R$ 89.000 do banco.', '2024-05-27 20:23:12'),
(2811, 13, 'Windsor recebeu R$ 89.000 do banco.', '2024-05-27 20:23:15'),
(2812, 13, 'Windsor recebeu R$ 8.000.000 do banco.', '2024-05-27 20:23:19'),
(2813, 13, 'Windsor recebeu R$ 78.000.000 do banco.', '2024-05-27 20:24:25'),
(2814, 13, 'Windsor recebeu R$ 78.000 do banco.', '2024-05-27 20:24:53'),
(2815, 13, 'Windsor pagou R$ 78.000.000 ao banco.', '2024-05-27 20:34:41');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(15,2) DEFAULT 15000000.00,
  `abandonou` tinyint(1) DEFAULT 0,
  `notificado` tinyint(1) DEFAULT 0,
  `last_reward_time` timestamp NULL DEFAULT NULL,
  `icone` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `nickname`, `password`, `balance`, `abandonou`, `notificado`, `last_reward_time`, `icone`) VALUES
(9, 'Carol', '$2y$10$vROwhNL/K1aESifSKIpwVuzrRL198sXICG4lJAbWCbwbcp0fY7Gfe', 15089000.00, 0, 0, '2024-05-27 18:37:58', 'fa-cash-register'),
(10, 'Monique', '$2y$10$8tojQsmGcXazi4ptPAzxXeZdivcaylHFPITdwyp.aNP6TlREPfymS', 15000000.00, 0, 0, '2024-05-27 06:16:36', NULL),
(11, 'Jhow', '$2y$10$GlCUEgb6MkHihHTI2/fPmO62s5.MNiIMLypYnu1b4rZqovpPowqZ2', 15000000.00, 0, 0, '2024-05-27 06:32:45', NULL),
(12, 'Roberto', '$2y$10$4TMbH0L5n4IABAjUQo7v5.VsEr9VLdKfjaczK6ltxfybCXKe1z7um', 15000000.00, 0, 0, '2024-05-27 17:54:20', NULL),
(13, 'Windsor', '$2y$10$XIYfCtsW134JoR8qxpaITeQl.jPduz//48Jvb0.kJVOVuzDZalF/i', 23167000.00, 0, 0, '2024-05-28 01:15:11', 'fa-briefcase'),
(17, 'Amanda', '$2y$10$r6ObXk884gsO9T6DossRVeA7haVm1pUXFtz2DRgjbF249P/rQaRVe', 15000000.00, 0, 0, '2024-05-28 00:24:50', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `game_status`
--
ALTER TABLE `game_status`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `game_timer`
--
ALTER TABLE `game_timer`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `jogando`
--
ALTER TABLE `jogando`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `objetivos`
--
ALTER TABLE `objetivos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nickname` (`nickname`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `game_status`
--
ALTER TABLE `game_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `game_timer`
--
ALTER TABLE `game_timer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `jogando`
--
ALTER TABLE `jogando`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=606;

--
-- AUTO_INCREMENT de tabela `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18458;

--
-- AUTO_INCREMENT de tabela `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2816;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
