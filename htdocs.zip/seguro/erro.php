<script>alert("Você não tem permissão para resetar o jogo! Solicite ao Windsor!");</script>

<?php sleep(5); header('Location: dashboard.php');?>