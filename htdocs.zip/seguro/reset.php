<?php
session_start();
include 'db_connection.php'; // Supondo que este arquivo tenha a conexão com o banco de dados

if (!isset($_SESSION['user_id'])) {
    header('Location: index.html'); // Redireciona para login se não estiver logado
    exit;
}

// Verifique se o usuário está logado e é um administrador (você pode ajustar esse critério conforme necessário)
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 13) {
    // Exibe uma mensagem de erro em um pop-up e redireciona para o dashboard
    echo "<script>
            alert('Você não tem permissão para resetar o jogo.');
            window.location.href = 'dashboard.php';
          </script>";
    exit;
}

// Atualizar os saldos dos usuários para 15 milhões
$sqlUpdateSaldo = "UPDATE users SET balance = 15000000.00";
if ($conn->query($sqlUpdateSaldo) === TRUE) {
    $mensagemSaldo = "Saldos dos usuários atualizados para 15 milhões.";
} else {
    $mensagemSaldo = "Erro ao atualizar os saldos dos usuários: " . $conn->error;
}

// Limpar as notificações do banco de dados
$sqlLimparNotificacoes = "DELETE FROM notifications";
if ($conn->query($sqlLimparNotificacoes) === TRUE) {
    $mensagemNotificacoes = "Notificações do banco de dados limpas.";
} else {
    $mensagemNotificacoes = "Erro ao limpar as notificações do banco de dados: " . $conn->error;
}

// Limpar as transações do banco de dados
$sqlLimparTransacoes = "DELETE FROM transactions";
if ($conn->query($sqlLimparTransacoes) === TRUE) {
    $mensagemTransacoes = "Transações do banco de dados limpas.";
} else {
    $mensagemTransacoes = "Erro ao limpar as notificações do banco de dados: " . $conn->error;
}

// Limpar os jogadores do banco de dados como 'jogando'
$sqlLimparJogando = "DELETE FROM jogando";
if ($conn->query($sqlLimparJogando) === TRUE) {
    $mensagemJogadores = "Jogadores removidos da partida.";
} else {
    $mensagemJogadores = "Erro ao limpar jogadores do banco de dados: " . $conn->error;
}

// Limpar os objetivos do banco de dados como 'ativo'
$sqlLimparObjetivos = "UPDATE objetivos SET status=0 WHERE status=1";
if ($conn->query($sqlLimparObjetivos) === TRUE) {
    $mensagemObjetivos = "Objetivos removidos da partida.";
} else {
    $mensagemObjetivos = "Erro ao limpar objetivos do banco de dados: " . $conn->error;
}

// Limpar os abandonos do banco de dados como 'ativo'
$sqlLimparAbandono = "UPDATE users SET abandonou = 0 WHERE abandonou = 1";
if ($conn->query($sqlLimparAbandono) === TRUE) {
    $mensagemAbandono = "Abandonos resetados.";
} else {
    $mensagemAbandono = "Erro ao limpar abandonos do banco de dados: " . $conn->error;
}

// Definir o status de reset do jogo
$sqlResetStatus = "UPDATE game_status SET reset_status = 1 WHERE id = 1";
$conn->query($sqlResetStatus);

$sqlResetNotificado = "UPDATE users SET notificado = 0 WHERE notificado = 1";
$conn->query($sqlResetNotificado);

$sqlResetObjetivos = "UPDATE objetivos SET assigned = 0 WHERE assigned = 1";
$conn->query($sqlResetObjetivos);

$sqlResetIcone = "UPDATE users SET icone = NULL WHERE icone IS NOT NULL";
$conn->query($sqlResetIcone);

$sqlResetLastReward = "UPDATE users SET last_reward_time = NULL WHERE last_reward_time IS NOT NULL";
$conn->query($sqlResetLastReward);

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/4a99debbd4.js" crossorigin="anonymous"></script>
    <title>Resetar Jogo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e4e4e4;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 50px auto;
        }
        h1 {
            color: #333;
        }
        p {
            color: #555;
        }
        a {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: #0056b3;
        }
        .button {
            background-color: #28a745;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Jogo Resetado!</h1>
        <p><?php echo $mensagemSaldo; ?></p>
        <p><?php echo $mensagemNotificacoes; ?></p>
        <p><?php echo $mensagemTransacoes; ?></p>
        <p><?php echo $mensagemJogadores; ?></p>
        <p><?php echo $mensagemObjetivos; ?></p>
		<p><?php echo $mensagemAbandono; ?></p>
        <a class="button" href="dashboard.php"><i class="fa-solid fa-rotate-left"></i> Voltar</a>
    </div>
	<script>
	const valorSaldo = 15000000;
            localStorage.setItem('saldoReal', 'R$ ' + valorSaldo.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }));
			</script>
</body>
</html>
