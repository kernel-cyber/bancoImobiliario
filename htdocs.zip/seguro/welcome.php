<?php
session_start(); // Inicia ou continua uma sessão

// Verifica se existe uma mensagem de sucesso na sessão
if (isset($_SESSION['success_message'])) {
    $message = $_SESSION['success_message'];
    unset($_SESSION['success_message']); // Limpa a mensagem após o uso para não exibir novamente
} else {
    $message = "Bem-vindo!";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem-vindo</title>
</head>
<body>
    <h1><?php echo $message; ?></h1>
    <p>Esta é a tela inicial do sistema.</p>
</body>
</html>
