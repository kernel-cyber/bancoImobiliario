-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 17/07/2024 às 17:29
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco_imobiliario`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `conjunto`
--

CREATE TABLE `conjunto` (
  `id` int(11) NOT NULL,
  `nome_conjunto` varchar(255) NOT NULL,
  `cor_conjunto` varchar(50) NOT NULL,
  `nome_propriedade` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `conjunto`
--

INSERT INTO `conjunto` (`id`, `nome_conjunto`, `cor_conjunto`, `nome_propriedade`) VALUES
(1, 'Amarelo', 'Amarelo', 'Av Niemeyer'),
(2, 'Rosa', 'Rosa', 'Av Higienopolis'),
(3, 'Amarelo', 'Amarelo', 'Av. Oscar Freire');

-- --------------------------------------------------------

--
-- Estrutura para tabela `game_status`
--

CREATE TABLE `game_status` (
  `id` int(11) NOT NULL,
  `reset_status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `game_status`
--

INSERT INTO `game_status` (`id`, `reset_status`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `game_timer`
--

CREATE TABLE `game_timer` (
  `id` int(11) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `remaining_time` int(11) DEFAULT 7200
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `game_timer`
--

INSERT INTO `game_timer` (`id`, `start_time`, `remaining_time`) VALUES
(1, '2024-05-26 04:35:48', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogando`
--

CREATE TABLE `jogando` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `objetivoId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `jogando`
--

INSERT INTO `jogando` (`id`, `userId`, `nickname`, `objetivoId`) VALUES
(687, 21, 'Dudu', 5);

-- --------------------------------------------------------

--
-- Estrutura para tabela `lances`
--

CREATE TABLE `lances` (
  `id` int(11) NOT NULL,
  `leilao_id` int(11) NOT NULL,
  `jogador_id` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `rodada` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `leiloes`
--

CREATE TABLE `leiloes` (
  `id` int(11) NOT NULL,
  `item` varchar(255) NOT NULL,
  `cor` varchar(50) NOT NULL,
  `propriedade` varchar(255) NOT NULL,
  `lance_minimo` decimal(10,2) NOT NULL,
  `jogador_id` int(11) NOT NULL,
  `lance_atual` decimal(10,2) DEFAULT 0.00,
  `jogador_lance_id` int(11) DEFAULT NULL,
  `rodada_atual` int(11) DEFAULT 1,
  `status` varchar(50) DEFAULT 'ativo',
  `jogador_vencedor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `read` tinyint(1) DEFAULT 0,
  `type` varchar(50) NOT NULL DEFAULT 'notification'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `created_at`, `read`, `type`) VALUES
(21892, 17, 'Dudu entrou na partida.', '2024-07-14 22:21:10', 0, 'join'),
(21893, 9, 'Dudu entrou na partida.', '2024-07-14 22:21:10', 0, 'join'),
(21894, 11, 'Dudu entrou na partida.', '2024-07-14 22:21:10', 0, 'join'),
(21896, 19, 'Dudu entrou na partida.', '2024-07-14 22:21:10', 0, 'join'),
(21897, 10, 'Dudu entrou na partida.', '2024-07-14 22:21:10', 0, 'join'),
(21898, 12, 'Dudu entrou na partida.', '2024-07-14 22:21:10', 0, 'join'),
(21899, 13, 'Dudu entrou na partida.', '2024-07-14 22:21:10', 0, 'join'),
(21901, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13', 0, 'transaction'),
(21902, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13', 0, 'transaction'),
(21903, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13', 0, 'transaction'),
(21905, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13', 0, 'transaction'),
(21906, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13', 0, 'transaction'),
(21907, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13', 0, 'transaction'),
(21908, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13', 0, 'transaction'),
(21909, 17, 'Lokes entrou na partida.', '2024-07-14 22:21:15', 0, 'join'),
(21910, 9, 'Lokes entrou na partida.', '2024-07-14 22:21:15', 0, 'join'),
(21912, 11, 'Lokes entrou na partida.', '2024-07-14 22:21:15', 0, 'join'),
(21913, 19, 'Lokes entrou na partida.', '2024-07-14 22:21:15', 0, 'join'),
(21914, 10, 'Lokes entrou na partida.', '2024-07-14 22:21:15', 0, 'join'),
(21915, 12, 'Lokes entrou na partida.', '2024-07-14 22:21:15', 0, 'join'),
(21916, 13, 'Lokes entrou na partida.', '2024-07-14 22:21:15', 0, 'join'),
(21918, 17, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18', 0, 'transaction'),
(21919, 9, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18', 0, 'transaction'),
(21921, 11, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18', 0, 'transaction'),
(21922, 19, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18', 0, 'transaction'),
(21923, 10, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18', 0, 'transaction'),
(21924, 12, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18', 0, 'transaction'),
(21925, 13, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18', 0, 'transaction'),
(21927, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26', 0, 'transaction'),
(21928, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26', 0, 'transaction'),
(21929, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26', 0, 'transaction'),
(21931, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26', 0, 'transaction'),
(21932, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26', 0, 'transaction'),
(21933, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26', 0, 'transaction'),
(21934, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26', 0, 'transaction'),
(21936, 17, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32', 0, 'success'),
(21937, 9, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32', 0, 'success'),
(21939, 11, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32', 0, 'success'),
(21940, 19, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32', 0, 'success'),
(21941, 10, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32', 0, 'success'),
(21942, 12, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32', 0, 'success'),
(21943, 13, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32', 0, 'success'),
(21944, 17, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:32', 0, 'rico'),
(21945, 9, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:32', 0, 'rico'),
(21947, 11, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:32', 0, 'rico'),
(21949, 19, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:32', 0, 'rico'),
(21950, 10, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:32', 0, 'rico'),
(21951, 12, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:32', 0, 'rico'),
(21952, 13, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:32', 0, 'rico'),
(21954, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42', 0, 'transaction'),
(21955, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42', 0, 'transaction'),
(21956, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42', 0, 'transaction'),
(21958, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42', 0, 'transaction'),
(21959, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42', 0, 'transaction'),
(21960, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42', 0, 'transaction'),
(21961, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42', 0, 'transaction'),
(21963, 17, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50', 0, 'success'),
(21964, 9, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50', 0, 'success'),
(21965, 11, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50', 0, 'success'),
(21967, 19, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50', 0, 'success'),
(21968, 10, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50', 0, 'success'),
(21969, 12, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50', 0, 'success'),
(21970, 13, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50', 0, 'success'),
(21971, 17, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:50', 0, 'rico'),
(21972, 9, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:50', 0, 'rico'),
(21974, 11, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:50', 0, 'rico'),
(21976, 19, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:50', 0, 'rico'),
(21977, 10, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:50', 0, 'rico'),
(21978, 12, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:50', 0, 'rico'),
(21979, 13, 'Um jogador atingiu R$ 30.000.000.', '2024-07-14 22:21:50', 0, 'rico'),
(21987, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01', 0, 'transaction'),
(21988, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01', 0, 'transaction'),
(21989, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01', 0, 'transaction'),
(21991, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01', 0, 'transaction'),
(21992, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01', 0, 'transaction'),
(21993, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01', 0, 'transaction'),
(21994, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01', 0, 'transaction'),
(21996, 17, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05', 0, 'transaction'),
(21997, 9, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05', 0, 'transaction'),
(21999, 11, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05', 0, 'transaction'),
(22000, 19, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05', 0, 'transaction'),
(22001, 10, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05', 0, 'transaction'),
(22002, 12, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05', 0, 'transaction'),
(22003, 13, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05', 0, 'transaction'),
(22005, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11', 0, 'transaction'),
(22006, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11', 0, 'transaction'),
(22007, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11', 0, 'transaction'),
(22009, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11', 0, 'transaction'),
(22010, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11', 0, 'transaction'),
(22011, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11', 0, 'transaction'),
(22012, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11', 0, 'transaction'),
(22015, 17, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19', 0, 'transaction'),
(22016, 9, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19', 0, 'transaction'),
(22018, 11, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19', 0, 'transaction'),
(22019, 19, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19', 0, 'transaction'),
(22020, 10, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19', 0, 'transaction'),
(22021, 12, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19', 0, 'transaction'),
(22022, 13, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19', 0, 'transaction'),
(22040, 17, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21', 0, 'success'),
(22041, 9, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21', 0, 'success'),
(22043, 11, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21', 0, 'success'),
(22044, 19, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21', 0, 'success'),
(22045, 10, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21', 0, 'success'),
(22046, 12, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21', 0, 'success'),
(22047, 13, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21', 0, 'success'),
(22049, 17, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27', 0, 'success'),
(22050, 9, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27', 0, 'success'),
(22052, 11, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27', 0, 'success'),
(22053, 19, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27', 0, 'success'),
(22054, 10, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27', 0, 'success'),
(22055, 12, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27', 0, 'success'),
(22056, 13, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27', 0, 'success'),
(22058, 17, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32', 0, 'success'),
(22059, 9, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32', 0, 'success'),
(22061, 11, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32', 0, 'success'),
(22062, 19, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32', 0, 'success'),
(22063, 10, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32', 0, 'success'),
(22064, 12, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32', 0, 'success'),
(22065, 13, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32', 0, 'success'),
(22067, 17, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40', 0, 'success'),
(22068, 9, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40', 0, 'success'),
(22070, 11, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40', 0, 'success'),
(22071, 19, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40', 0, 'success'),
(22072, 10, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40', 0, 'success'),
(22073, 12, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40', 0, 'success'),
(22074, 13, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40', 0, 'success'),
(22076, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41', 0, 'transaction'),
(22077, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41', 0, 'transaction'),
(22078, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41', 0, 'transaction'),
(22080, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41', 0, 'transaction'),
(22081, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41', 0, 'transaction'),
(22082, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41', 0, 'transaction'),
(22083, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41', 0, 'transaction'),
(22084, 17, 'Lokes abandonou a partida.', '2024-07-14 22:24:52', 0, 'warning'),
(22085, 9, 'Lokes abandonou a partida.', '2024-07-14 22:24:52', 0, 'warning'),
(22087, 11, 'Lokes abandonou a partida.', '2024-07-14 22:24:52', 0, 'warning'),
(22089, 19, 'Lokes abandonou a partida.', '2024-07-14 22:24:52', 0, 'warning'),
(22090, 10, 'Lokes abandonou a partida.', '2024-07-14 22:24:52', 0, 'warning'),
(22091, 12, 'Lokes abandonou a partida.', '2024-07-14 22:24:52', 0, 'warning'),
(22092, 13, 'Lokes abandonou a partida.', '2024-07-14 22:24:52', 0, 'warning'),
(22094, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22095, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22096, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22097, 22, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22098, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22099, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22100, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22101, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53', 0, 'transaction'),
(22103, 17, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction'),
(22104, 9, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction'),
(22105, 11, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction'),
(22106, 22, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction'),
(22107, 19, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction'),
(22108, 10, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction'),
(22109, 12, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction'),
(22110, 13, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03', 0, 'transaction');

-- --------------------------------------------------------

--
-- Estrutura para tabela `objetivos`
--

CREATE TABLE `objetivos` (
  `id` int(11) NOT NULL,
  `nome_objetivo` varchar(255) DEFAULT NULL,
  `descricao_objetivo` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `objetivo1` varchar(255) DEFAULT NULL,
  `objetivo2` varchar(255) DEFAULT NULL,
  `objetivo3` varchar(255) DEFAULT NULL,
  `objetivo4` varchar(255) DEFAULT NULL,
  `assigned` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `objetivos`
--

INSERT INTO `objetivos` (`id`, `nome_objetivo`, `descricao_objetivo`, `status`, `objetivo1`, `objetivo2`, `objetivo3`, `objetivo4`, `assigned`) VALUES
(1, 'Magnata das Conexões', 'Adquirir ação da Viação Garcia e construir pelo menos 6 casas em propriedades próximas a ação.', 0, 'Ação da <b><font color=\"#003f7c\">Viação Garcia</font></b>', '6 Casas', '', NULL, 0),
(2, 'Mestre da Comunicação', 'Controlar as ações da Mastercard e Globo, construir pelo menos 6 casas em propriedades no conjunto roxo.', 0, 'Ações <b><font color=\'Red\'>Master</font><font color=\"orange\">card</font></b> e <b><font color=\"#E60012\">G</font><font color=\"#EA4C89\">l</font><font color=\"#FAA61A\">o</font><font color=\"#8BC34A\">b</font><font color=\"#03A9F4\">o</font></b>', '6 <font color=\"purple\"><b>Casas</b></font>', '', NULL, 0),
(3, 'Urbanista', 'Adquirir um conjunto completo de propriedades de qualquer cor e construir 1 hotel e pelo menos 4 casas nesse conjunto.', 0, '1 Conj.', '1 Hotel', '4 Casas', NULL, 0),
(4, 'Comerciante Estratégico', 'Adquirir todos os conjuntos de propriedades de cores laranja ou amarelo, construir 6 casas e investir em ações da Petrobras.', 0, 'Conj. <font color=\"orange\"><b>Lar.</b></font> ou <font color=\"gold\"><b>Ama.</b></font>', 'Ação <b><font color=\"green\">Petrobras</font></b>', '6 Casas', NULL, 1),
(5, 'Colecionador Versátil', 'Possuir um conjunto completo de propriedades de qualquer cor e construir 5 casas nessas propriedades. Adquirir ações de pelo menos três tipos diferentes.', 0, '1 Conj.', '5 Casas', '3 Ações', NULL, 1),
(6, 'Estrategista de Elite', 'Adquirir todas as propriedades do conjunto verde escuro ou azul, construir 6 casas nessas propriedades e adquirir ações da GOL e Mercado Livre.', 0, 'Conj. <font color=\"#006400\"><b>Verde Esc.</b></font> ou <font color=\"blue\"><b>Azul</b></font>', '6 Casas', 'Ação <font color=\"orage\">G</font><font color=\"gray\">O</font><font color=\"oragen\">L</font> e <font color=\"gold\">Mercado Livre</font>', NULL, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `message`, `created_at`) VALUES
(3225, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:13'),
(3226, 22, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:18'),
(3227, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:26'),
(3228, 22, 'Lokes recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:32'),
(3229, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:21:42'),
(3230, 21, 'Dudu recebeu R$ 9.223.372.036.854.775.808 do banco.', '2024-07-14 22:21:50'),
(3231, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:01'),
(3232, 22, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:05'),
(3233, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:11'),
(3234, 22, 'Lokes recebeu R$ 2.000.000 do banco.', '2024-07-14 22:23:19'),
(3235, 22, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:21'),
(3236, 22, 'Lokes pagou R$ 1.000.000.000.000 ao banco.', '2024-07-14 22:24:27'),
(3237, 22, 'Lokes pagou R$ 999.999.999.999 ao banco.', '2024-07-14 22:24:32'),
(3238, 22, 'Lokes pagou R$ 7.000.000.000.000 ao banco.', '2024-07-14 22:24:40'),
(3239, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:41'),
(3240, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:24:53'),
(3241, 21, 'Dudu recebeu R$ 2.000.000 do banco.', '2024-07-14 22:25:03');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(15,2) DEFAULT 15000000.00,
  `abandonou` tinyint(1) DEFAULT 0,
  `notificado` tinyint(1) DEFAULT 0,
  `last_reward_time` timestamp NULL DEFAULT NULL,
  `icone` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `nickname`, `password`, `balance`, `abandonou`, `notificado`, `last_reward_time`, `icone`) VALUES
(9, 'Carol', '$2y$10$vROwhNL/K1aESifSKIpwVuzrRL198sXICG4lJAbWCbwbcp0fY7Gfe', 15000000.00, 0, 0, NULL, NULL),
(10, 'Monique', '$2y$10$8tojQsmGcXazi4ptPAzxXeZdivcaylHFPITdwyp.aNP6TlREPfymS', 15000000.00, 0, 0, NULL, NULL),
(11, 'Jhow', '$2y$10$GlCUEgb6MkHihHTI2/fPmO62s5.MNiIMLypYnu1b4rZqovpPowqZ2', 15000000.00, 0, 0, NULL, NULL),
(12, 'Roberto', '$2y$10$4TMbH0L5n4IABAjUQo7v5.VsEr9VLdKfjaczK6ltxfybCXKe1z7um', 15000000.00, 0, 0, NULL, NULL),
(13, 'Windsor', '$2y$10$XIYfCtsW134JoR8qxpaITeQl.jPduz//48Jvb0.kJVOVuzDZalF/i', 15000000.00, 0, 0, NULL, NULL),
(17, 'Amanda', '$2y$10$r6ObXk884gsO9T6DossRVeA7haVm1pUXFtz2DRgjbF249P/rQaRVe', 15000000.00, 0, 0, NULL, NULL),
(19, 'Luka', '$2y$10$8h1aGuA8Ey/CtfstRlZ5auMWkK8pOMJttDjnGytVKWMIQFPbNNc9C', 15000000.00, 0, 0, NULL, NULL),
(21, 'Dudu', '$2y$10$3GF5C2W8P14SVTu91OhtBOHMLU4AjxJTLJUknz9g7JNPlZMb5foky', 9999999999999.99, 0, 1, '2024-07-15 03:25:03', 'fa-dollar-sign'),
(22, 'Lokes', '$2y$10$mKOHKWFhK1R6X4Q6PlRDueklXtSlgsanSIR7JAlJmmzpLM8oDZHKi', 0.00, 1, 0, '2024-07-15 03:23:19', 'fa-sack-dollar');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `conjunto`
--
ALTER TABLE `conjunto`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `game_status`
--
ALTER TABLE `game_status`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `game_timer`
--
ALTER TABLE `game_timer`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `jogando`
--
ALTER TABLE `jogando`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `lances`
--
ALTER TABLE `lances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leilao_id` (`leilao_id`),
  ADD KEY `jogador_id` (`jogador_id`);

--
-- Índices de tabela `leiloes`
--
ALTER TABLE `leiloes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jogador_id` (`jogador_id`),
  ADD KEY `jogador_lance_id` (`jogador_lance_id`);

--
-- Índices de tabela `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `objetivos`
--
ALTER TABLE `objetivos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nickname` (`nickname`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `conjunto`
--
ALTER TABLE `conjunto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `game_status`
--
ALTER TABLE `game_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `game_timer`
--
ALTER TABLE `game_timer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `jogando`
--
ALTER TABLE `jogando`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=689;

--
-- AUTO_INCREMENT de tabela `lances`
--
ALTER TABLE `lances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT de tabela `leiloes`
--
ALTER TABLE `leiloes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=384;

--
-- AUTO_INCREMENT de tabela `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22114;

--
-- AUTO_INCREMENT de tabela `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3242;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `lances`
--
ALTER TABLE `lances`
  ADD CONSTRAINT `lances_ibfk_1` FOREIGN KEY (`leilao_id`) REFERENCES `leiloes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lances_ibfk_2` FOREIGN KEY (`jogador_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `leiloes`
--
ALTER TABLE `leiloes`
  ADD CONSTRAINT `leiloes_ibfk_1` FOREIGN KEY (`jogador_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `leiloes_ibfk_2` FOREIGN KEY (`jogador_lance_id`) REFERENCES `users` (`id`);

--
-- Restrições para tabelas `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
